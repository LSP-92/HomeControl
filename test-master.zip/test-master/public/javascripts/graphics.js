
export function renderChart (){
  Chart.platform.disableCSSInjection = true;
  const ctx = document.querySelector('#myChart').getContext('2d')
  const bton = document.querySelector('#reload')

  const chart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: 'Temperatura',
        data: [],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)'
        ],  
        borderWidth: 5,
      }]},
    options: {
      scales: {
        yAxes: [{
          ticks: {
            max: 50,
            min: -10,
            stepSize: 5,
          }
        }]
      }
    }
  })

  bton.addEventListener('click', readTemp)
  const url = 'https://api.tutiempo.net/json/?lan=es&apid=XxD4zqqzaaqXuh7&ll=40.4178,-3.7022'

  async function readTemp() {
    fetch(url)
      .then(res => {
        if (res.status !== 200) {
          alert('Error Servidor de tiempo...')
        }
        return res.json()
      })
      .then(data => {
        console.log(data)
        addData(chart, data.day1.date, data.day1.temperature_max)
        addData(chart, data.day2.date, data.day2.temperature_max)
        addData(chart, data.day3.date, data.day3.temperature_max)
        addData(chart, data.day4.date, data.day4.temperature_max)
        addData(chart, data.day5.date, data.day5.temperature_max)
        addData(chart, data.day6.date, data.day6.temperature_max)
      })
      .catch((err) => console.log(err)/* alert('Error Servidor...') */ )
  }
  

  function addData(chart, day, data) {    
    console.log(data)
    chart.data.labels.push(day)
    chart.data.datasets.forEach((dataset) => {
        dataset.data.push(data)
    })
    if (chart.data.labels.length === 7){
      chart.data.datasets[0].data.splice(0, 1)
      chart.data.labels.splice(0, 5)
    }
    
    chart.update()
  }

}



